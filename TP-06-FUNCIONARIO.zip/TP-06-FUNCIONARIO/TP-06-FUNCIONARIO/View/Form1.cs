﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP_06_FUNCIONARIO.Controller;
using TP_06_FUNCIONARIO.Model;

namespace TP_06_FUNCIONARIO
{
    public partial class Form1: Form
    {
        FuncionarioController controller = new FuncionarioController();
        public Form1()
        {
            InitializeComponent();
        }

        private void btFiltrar_Click(object sender, EventArgs e)
        {
            
            string filtro = txtFiltro.Text;
            var resultado = controller.FiltrarFuncionario(filtro);

            if (resultado.Any())
            {
                foreach (var f in resultado)
                {
                    listFuncionario.Items.Add($"{f.Nome} - {f.Departamento} - {f.Salario} - {f.AnosDeServico}");
                }
            }
            else
            {
                listFuncionario.Items.Add("Nenhum funcionario encontrado.");
            }

        }

        private void btMaiusculas_Click(object sender, EventArgs e)
        {
         

            listFuncionario.Items.Clear();
            listFuncionario.Items.Add("Nomes em maiúsculas");

            var nomesMaiusculos = controller.ListarNomesMaiusculos();
            foreach (var nome in nomesMaiusculos)
            {
                listFuncionario.Items.Add(nome);
            }
        }

        private void btAgrupar_Click(object sender, EventArgs e)
        {
         
            var agrupados = controller.AgruparFuncionarios();

            listFuncionario.Items.Clear();
            listFuncionario.Items.Add("Funcionarios agrupados por inicial:");

            foreach (var grupo in agrupados)
            {
                listFuncionario.Items.Add($"Inicial: {grupo.Key}");

                foreach (var f in grupo)
                {
                    listFuncionario.Items.Add($"  {f.Nome}");
                }
            }

        }

        private void btSalarios_Click_1(object sender, EventArgs e)
        {
            double total = controller.CalcularSalarios();

            listFuncionario.Items.Clear();
            listFuncionario.Items.Add($"Total gasto com salários: R$ {total:F2}");

        }

        private void btMDepartamentos_Click_1(object sender, EventArgs e)
        {
            var medias = controller.AgruparPorDepartamentoComMedia();

            listFuncionario.Items.Clear();
            listFuncionario.Items.Add("Média salarial por departamento:");

            foreach (var item in medias)
            {
                listFuncionario.Items.Add($"Departamento: {item.Departamento} - Média: R$ {item.MediaSalarial:F2}");
            }

        }

        private void btReajuste_Click(object sender, EventArgs e)
        {
            var funcionarios = controller.ReajusteSalarial();

            listFuncionario.Items.Clear();
            listFuncionario.Items.Add("Funcionários (após reajuste de 5% para > 10 anos):");

            foreach (var f in funcionarios)
            {
                listFuncionario.Items.Add($"{f.Nome} - {f.AnosDeServico} anos - Novo Salário: R$ {f.Salario:F2}");
            }
        }

        private void btFunAntigo_Click(object sender, EventArgs e)
        {
            var funcionario = controller.EncontrarFuncionarioMaisTempoServico();

            listFuncionario.Items.Clear();

            if (funcionario != null)
            {
                listFuncionario.Items.Add($"Funcionário com mais tempo de serviço:");
                listFuncionario.Items.Add($"{funcionario.Nome} - {funcionario.AnosDeServico} anos - Salário: R$ {funcionario.Salario:F2}");
            }
            else
            {
                listFuncionario.Items.Add("Nenhum funcionário encontrado.");
            }
        }

   
    }
}
