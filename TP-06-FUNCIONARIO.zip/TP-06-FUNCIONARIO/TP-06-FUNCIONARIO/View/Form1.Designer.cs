﻿namespace TP_06_FUNCIONARIO
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btMaiusculas = new System.Windows.Forms.Button();
            this.btFiltrar = new System.Windows.Forms.Button();
            this.btAgrupar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.listFuncionario = new System.Windows.Forms.ListBox();
            this.btSalarios = new System.Windows.Forms.Button();
            this.btMDepartamentos = new System.Windows.Forms.Button();
            this.btReajuste = new System.Windows.Forms.Button();
            this.btFunAntigo = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btMaiusculas
            // 
            this.btMaiusculas.Location = new System.Drawing.Point(136, 142);
            this.btMaiusculas.Name = "btMaiusculas";
            this.btMaiusculas.Size = new System.Drawing.Size(75, 23);
            this.btMaiusculas.TabIndex = 0;
            this.btMaiusculas.Text = "Maiusculas";
            this.btMaiusculas.UseVisualStyleBackColor = true;
            this.btMaiusculas.Click += new System.EventHandler(this.btMaiusculas_Click);
            // 
            // btFiltrar
            // 
            this.btFiltrar.Location = new System.Drawing.Point(38, 142);
            this.btFiltrar.Name = "btFiltrar";
            this.btFiltrar.Size = new System.Drawing.Size(75, 23);
            this.btFiltrar.TabIndex = 1;
            this.btFiltrar.Text = "Filtrar";
            this.btFiltrar.UseVisualStyleBackColor = true;
            this.btFiltrar.Click += new System.EventHandler(this.btFiltrar_Click);
            // 
            // btAgrupar
            // 
            this.btAgrupar.Location = new System.Drawing.Point(233, 142);
            this.btAgrupar.Name = "btAgrupar";
            this.btAgrupar.Size = new System.Drawing.Size(75, 23);
            this.btAgrupar.TabIndex = 2;
            this.btAgrupar.Text = "Agrupar";
            this.btAgrupar.UseVisualStyleBackColor = true;
            this.btAgrupar.Click += new System.EventHandler(this.btAgrupar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Filtro";
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(100, 89);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(163, 20);
            this.txtFiltro.TabIndex = 4;
            // 
            // listFuncionario
            // 
            this.listFuncionario.FormattingEnabled = true;
            this.listFuncionario.Location = new System.Drawing.Point(38, 244);
            this.listFuncionario.Name = "listFuncionario";
            this.listFuncionario.Size = new System.Drawing.Size(270, 212);
            this.listFuncionario.TabIndex = 5;
            // 
            // btSalarios
            // 
            this.btSalarios.Location = new System.Drawing.Point(38, 171);
            this.btSalarios.Name = "btSalarios";
            this.btSalarios.Size = new System.Drawing.Size(75, 23);
            this.btSalarios.TabIndex = 6;
            this.btSalarios.Text = "Salarios";
            this.btSalarios.UseVisualStyleBackColor = true;
            this.btSalarios.Click += new System.EventHandler(this.btSalarios_Click_1);
            // 
            // btMDepartamentos
            // 
            this.btMDepartamentos.Location = new System.Drawing.Point(136, 171);
            this.btMDepartamentos.Name = "btMDepartamentos";
            this.btMDepartamentos.Size = new System.Drawing.Size(75, 23);
            this.btMDepartamentos.TabIndex = 7;
            this.btMDepartamentos.Text = "M. Departa.";
            this.btMDepartamentos.UseVisualStyleBackColor = true;
            this.btMDepartamentos.Click += new System.EventHandler(this.btMDepartamentos_Click_1);
            // 
            // btReajuste
            // 
            this.btReajuste.Location = new System.Drawing.Point(233, 171);
            this.btReajuste.Name = "btReajuste";
            this.btReajuste.Size = new System.Drawing.Size(75, 23);
            this.btReajuste.TabIndex = 8;
            this.btReajuste.Text = "Reajuste";
            this.btReajuste.UseVisualStyleBackColor = true;
            this.btReajuste.Click += new System.EventHandler(this.btReajuste_Click);
            // 
            // btFunAntigo
            // 
            this.btFunAntigo.Location = new System.Drawing.Point(88, 200);
            this.btFunAntigo.Name = "btFunAntigo";
            this.btFunAntigo.Size = new System.Drawing.Size(75, 23);
            this.btFunAntigo.TabIndex = 9;
            this.btFunAntigo.Text = "F. Antigo";
            this.btFunAntigo.UseVisualStyleBackColor = true;
            this.btFunAntigo.Click += new System.EventHandler(this.btFunAntigo_Click);
            // 
            // btSair
            // 
            this.btSair.Location = new System.Drawing.Point(188, 200);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(75, 23);
            this.btSair.TabIndex = 10;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = true;
    
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 494);
            this.Controls.Add(this.btSair);
            this.Controls.Add(this.btFunAntigo);
            this.Controls.Add(this.btReajuste);
            this.Controls.Add(this.btMDepartamentos);
            this.Controls.Add(this.btSalarios);
            this.Controls.Add(this.listFuncionario);
            this.Controls.Add(this.txtFiltro);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btAgrupar);
            this.Controls.Add(this.btFiltrar);
            this.Controls.Add(this.btMaiusculas);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btMaiusculas;
        private System.Windows.Forms.Button btFiltrar;
        private System.Windows.Forms.Button btAgrupar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.ListBox listFuncionario;
        private System.Windows.Forms.Button btSalarios;
        private System.Windows.Forms.Button btMDepartamentos;
        private System.Windows.Forms.Button btReajuste;
        private System.Windows.Forms.Button btFunAntigo;
        private System.Windows.Forms.Button btSair;
    }
}

