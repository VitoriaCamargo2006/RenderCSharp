﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP_06_FUNCIONARIO.Model;

namespace TP_06_FUNCIONARIO.Controller
{
    class FuncionarioController
    {
        public FuncionarioModel model = new FuncionarioModel();
        
        public List<Funcionario> FiltrarFuncionario (string filtro)
        {
            if (string.IsNullOrEmpty(filtro) || filtro.Length > 1)
                return new List<Funcionario>(); //Aq ele está retornando a lista vazia, em caso de erro


            if (double.TryParse(filtro, out double salarioMinimo))
                return model.ListarFuncionarios()
                    .Where(f => f.Salario > salarioMinimo)
                    .ToList();
            

            if (filtro.Length == 1)
              return  model.ListarFuncionarios()
                .Where(m => m.Nome.StartsWith(filtro, StringComparison.OrdinalIgnoreCase))
                .OrderBy(f => f.Nome)
                .ToList();
            

            
        }

        public List<string> ListarNomesMaiusculos()
        {
            var funcionarios = model.ListarFuncionarios(); 
            return funcionarios.Select(f => f.Nome.ToUpper()).ToList();
        }

        public List<IGrouping<char, Funcionario>> AgruparFuncionarios()
        {
            var clientes = model.ListarFuncionarios(); 
            return clientes
                .GroupBy(c => char.ToUpper(c.Nome[0])) 
                .ToList();
        }


        public double CalcularSalarios()
        {
            return model.ListarFuncionarios()
                        .Sum(f => f.Salario); 
        }

        public List<(string Departamento, double MediaSalarial)> AgruparPorDepartamentoComMedia()
        {
            var funcionarios = model.ListarFuncionarios();

            return funcionarios
                .GroupBy(f => f.Departamento)
                .Select(g => (
                    Departamento: g.Key,
                    MediaSalarial: g.Average(f => f.Salario)
                ))
                .ToList();
        }

        public List<Funcionario> ReajusteSalarial()
        {
            var funcionarios = model.ListarFuncionarios();

            foreach (var f in funcionarios)
            {
                if (f.AnosDeServico > 10)
                {
                    f.Salario = f.Salario + (f.Salario * 0.05); 
                }
            }

            return funcionarios;
        }

        public Funcionario EncontrarFuncionarioMaisTempoServico()
        {
            var funcionarios = model.ListarFuncionarios();

            return funcionarios
                .OrderByDescending(f => f.AnosDeServico) 
                .FirstOrDefault(); 
        }



    }
}
