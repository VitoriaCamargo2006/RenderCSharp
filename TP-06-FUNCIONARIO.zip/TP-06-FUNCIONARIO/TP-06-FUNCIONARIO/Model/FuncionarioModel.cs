﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_06_FUNCIONARIO.Model
{
    class FuncionarioModel
    {
        private List<Funcionario> funcionario = new List<Funcionario>
        {
         new Funcionario { Nome = "Ana", Departamento = "Recursos Humanos (RH)", Salario = 2000, AnosDeServico = 2},
         new Funcionario { Nome = "Gustavo", Departamento = "Vendas", Salario = 5000, AnosDeServico = 1},
         new Funcionario { Nome = "Henrique", Departamento = "Gestão", Salario = 3000, AnosDeServico = 3},
         new Funcionario { Nome = "Paula", Departamento = "Limpeza", Salario = 1800, AnosDeServico = 10},
        };

        public List<Funcionario> ListarFuncionarios()
        {
            return funcionario;
        }


    }
}
